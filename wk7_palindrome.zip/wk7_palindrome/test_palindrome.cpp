//filename: test_palindrome.cpp
//author: kyle bui
//date: 11/15/22

#include "queue1.h"
#include "stack1.h"
#include <iostream>
using namespace std;
using namespace kyle_bui;

void get_words_queue(queue<string>& q1);
void get_words_stack(stack<string>& s1);\

int main()
{
	queue<string> q1;

	get_words_queue(q1);
	
	cout << endl;

	if( q1.compare() == 1)
		cout << "queue is a palindrome" << endl;
	else
		cout << "queue is not a palindrome" << endl;

	cout << endl;

	stack<string> s1;

	get_words_stack(s1);
	
	cout << endl;

	if (s1.balance() == 1)
		cout << "stack is a palindrome" << endl;
	else
		cout << "stack is not a palindrome" << endl;

	return EXIT_SUCCESS;
}

void get_words_queue(queue<string>& q1)
{
	string user_input;

	cout << "Enter a palindrome sentance with each word seperated by an enter " << endl;
	cout << "Type DONE when you have entered all the words" << endl << endl;
	cin >> user_input; 


	while(user_input != "DONE" && user_input != "done")
	{
		q1.push(user_input);
		cin >> user_input;
	}
}

void get_words_stack(stack<string>& s1)
{
	string user_input;

	cout << "Enter a palindrome sentance with each word seperated by an enter " << endl;
	cout << "Type DONE when you have entered all the words" << endl << endl;
	cin >> user_input;

	while(user_input != "DONE" && user_input != "done")
	{
		s1.push(user_input);
		cin >> user_input;
	}

}
		
